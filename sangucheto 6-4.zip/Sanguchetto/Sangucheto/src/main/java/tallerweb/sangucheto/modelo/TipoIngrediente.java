package tallerweb.sangucheto.modelo;

public enum TipoIngrediente {

    INGREDIENTE,
    CONDIMENTO;
}
