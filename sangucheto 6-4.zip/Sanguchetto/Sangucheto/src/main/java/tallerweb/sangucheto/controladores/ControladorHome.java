package tallerweb.sangucheto.controladores;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import tallerweb.sangucheto.modelo.Ingrediente;
import tallerweb.sangucheto.modelo.IngredienteConStock;
import tallerweb.sangucheto.modelo.Stock;

@Controller
public class ControladorHome {
private ArrayList<IngredienteConStock> miSanguchetto=new ArrayList<IngredienteConStock>();
private Double precioTotalSanguchetto=0.0;
	public ArrayList<IngredienteConStock> getMiSanguchetto() {
	return miSanguchetto;
}
public void setMiSanguchetto(ArrayList<IngredienteConStock> miSanguchetto) {
	this.miSanguchetto = miSanguchetto;
}
public Double getPrecioTotalSanguchetto() {
	return precioTotalSanguchetto;
}
public void setPrecioTotalSanguchetto(Double precioTotalSanguchetto) {
	this.precioTotalSanguchetto = precioTotalSanguchetto;
}
	@RequestMapping(path="home")
	public ModelAndView irAHome(){
		return new ModelAndView("home");
	}
	@RequestMapping(path="contacto")
	public ModelAndView irAContacto(){
		return new ModelAndView("contacto");
	}
	@RequestMapping ("/agregarIngrediente")
	public ModelAndView irAIngrediente(){
		ModelMap model = new ModelMap();
		Ingrediente miIngrediente = new Ingrediente();
		model.put("ingrediente", miIngrediente);
		return new ModelAndView("agregarIngrediente",model);
	}
	@RequestMapping ("/comprarStock")
	public ModelAndView comprarStock(){
		ModelMap model = new ModelMap();
		Stock miStock= Stock.getInstance();
		ArrayList<IngredienteConStock> misIngredientes=new ArrayList<IngredienteConStock>(); 
		
		IngredienteConStock miIngrediente = new IngredienteConStock();
		ArrayList<IngredienteConStock> misCondimentos=new ArrayList<IngredienteConStock>();
		misIngredientes=miStock.devolverIngredientes();
		misCondimentos=miStock.devolverCondimentos();
		
		model.put("ingrediente", miIngrediente);
		model.put("stock", misIngredientes);
		model.put("stockCondimentos", misCondimentos);
		return new ModelAndView("comprarStock",model);
	}
	@RequestMapping (path = "/stockComprado", method = RequestMethod.POST)
	public ModelAndView stockComprado(@ModelAttribute ("ingrediente") IngredienteConStock miIngredienteComprado){
		ModelMap model = new ModelMap();
		Stock miStock= Stock.getInstance();
		
		Ingrediente ingredienteIncrementado=new Ingrediente(miIngredienteComprado.getNombre(),miIngredienteComprado.getPrecio(),miIngredienteComprado.getTipo());
		
		miStock.agregarStock(ingredienteIncrementado, miIngredienteComprado.getCantidad());
		
		ArrayList<IngredienteConStock> misIngredientes=new ArrayList<IngredienteConStock>();
		ArrayList<IngredienteConStock> misCondimentos=new ArrayList<IngredienteConStock>();
		misIngredientes=miStock.devolverIngredientes();
		misCondimentos=miStock.devolverCondimentos();
		IngredienteConStock miIngrediente = new IngredienteConStock();
		model.put("ingrediente", miIngrediente);
		model.put("stock", misIngredientes);
		model.put("stockCondimentos", misCondimentos);
		
		return new ModelAndView("comprarStock",model);
}
	@RequestMapping (path = "/agregado", method = RequestMethod.POST)
	public ModelAndView AgregarIngrediente(@ModelAttribute ("ingrediente") Ingrediente miIngrediente){
		ModelMap model = new ModelMap();
		/*model.put("nombre", miPersona.getNombre());
		model.put("apellido", miPersona.getApellido());
		model.put("mail", miPersona.getMail());*/
		Stock miStock= Stock.getInstance();
		miStock.agregarIngrediente(miIngrediente);
		model.put("lista", miStock.devolverListaEntera());
		
		return new ModelAndView ("stock",model);
}
	@RequestMapping(path="/verStock")
	public ModelAndView irAStock(){
		Stock miStock= Stock.getInstance();
		ModelMap model = new ModelMap();
		ArrayList<IngredienteConStock> misIngredientes=new ArrayList<IngredienteConStock>();
		misIngredientes=miStock.devolverListaEntera();
		model.put("lista", misIngredientes);
		return new ModelAndView("stock", model);
	}
	@RequestMapping ("/pedido")
	public ModelAndView irAHacerPedido(){
		ModelMap model = new ModelMap();
		IngredienteConStock miIngrediente = new IngredienteConStock();
		Stock miStock= Stock.getInstance();

		model.put("ingrediente", miIngrediente);
		model.put("stock", miStock.listarIngredientesConStock());
		
		return new ModelAndView("pedido",model);
	}
	//modificar la siguiente funcion con un arraylist, haceme caso XD
	@RequestMapping (path = "/sumado", method = RequestMethod.POST)
	public ModelAndView AgregarIngredientez(@ModelAttribute ("ingrediente") Ingrediente miIngrediente){
		ModelMap model = new ModelMap();
		/*model.put("nombre", miPersona.getNombre());
		model.put("apellido", miPersona.getApellido());
		model.put("mail", miPersona.getMail());*/
		Stock miStock= Stock.getInstance();
		IngredienteConStock ingredienteSanguchetto=new IngredienteConStock(miIngrediente.getNombre(),
				miIngrediente.getPrecio(), miIngrediente.getTipo(),1);
		this.miSanguchetto.add(ingredienteSanguchetto);
		miStock.restarStock(miIngrediente);
		
		
		model.put("ingrediente", miIngrediente);
		model.put("stock", miStock.listarIngredientesDisponibles());
		
		return new ModelAndView("pedido",model);
}
}